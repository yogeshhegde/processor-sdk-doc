ReadMe.txt


Steps to flash the binary are the same as those used earlier.
SD Card Image for the package also remains the same.

Examples:
Set board to UART boot.
Run serial flashing utility sfh_omapl138 with following options.

sfh_OMAP-L138.exe -targettype OMAPL138_LCDK -flashtype NAND -p COMx -erase (Skip this if you are not reflashing a corrupt NAND image)

sfh_OMAP-L138.exe -targettype C6748_LCDK -flashtype NAND -p COMx -flash_noubl facedetect_lcdk.bin.


After the image is flashed set the boot switches to NAND and follow the steps in the QSG.